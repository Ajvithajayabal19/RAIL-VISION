const $ = id => document.getElementById(id);
const speed = $("speed");
speed.addEventListener("input", () => $("speedValue").textContent = speed.value);

async function post(path, body={}) {
  try {
    const res = await fetch(path, {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const data = await res.json();
    $("feedback").textContent = data.message || (data.ok ? "Command sent" : "Command failed");
    if (!res.ok) $("feedback").textContent += " — check ESP32 USB/COM port.";
  } catch(e) { $("feedback").textContent = "Backend not reachable. Start python app.py."; }
}
document.querySelectorAll("[data-cmd]").forEach(btn => btn.addEventListener("click", () => post("/api/move",{command:btn.dataset.cmd,speed:Number(speed.value)})));
$("stop").addEventListener("click", () => post("/api/stop"));
$("refresh").addEventListener("click", refreshEvents);

async function refreshStatus(){
  try{
    const r=await fetch("/api/status"); const d=await r.json();
    $("esp").textContent=d.esp32.connected?"Connected":"Disconnected";
    $("esp").style.color=d.esp32.connected?"#54dfb7":"#ff8c8c";
    $("port").textContent=`Port: ${d.esp32.port} · Available: ${(d.available_ports||[]).join(", ")||"none"}`;
    $("cam").textContent=d.camera.connected?"Connected":"Not detected";
    $("cam").style.color=d.camera.connected?"#54dfb7":"#ffbd70";
    $("caminfo").textContent=d.camera.error||`Camera index: ${d.camera.index}`;
    $("yolo").textContent=d.yolo.available?"Loaded":"Unavailable";
    $("yolo").style.color=d.yolo.available?"#54dfb7":"#ffbd70";
    $("yoloinfo").textContent=d.yolo.message;
    $("robot").textContent=d.esp32.state||"Unknown";
    $("speedLabel").textContent=`Speed: ${d.esp32.speed||0}`;
    if(!d.camera.connected) $("videoFallback").style.display="block";
    else $("videoFallback").style.display="none";
  }catch(e){$("feedback").textContent="Cannot reach backend. Run python app.py";}
}
async function refreshEvents(){
  try{
    const r=await fetch("/api/events");const items=await r.json();
    $("eventList").innerHTML=items.length?items.map(e=>`<div class="event"><span><b>${escapeHtml(e.kind)}</b> — ${escapeHtml(e.message)}${e.confidence!==null?` (${Math.round(e.confidence*100)}%)`:""}</span><small>${e.time}</small></div>`).join(""):'<p class="empty">No events yet. YOLO detections will appear here when a model is loaded.</p>';
  }catch(e){}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
refreshStatus();refreshEvents();setInterval(refreshStatus,2500);setInterval(refreshEvents,4000);
