import os, json, time, threading
from collections import deque
from pathlib import Path

import cv2
import serial
from serial.tools import list_ports
from flask import Flask, Response, jsonify, request, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()
ROOT = Path(__file__).resolve().parent
app = Flask(__name__, static_folder="dashboard", static_url_path="")
CORS(app)

SERIAL_PORT = os.getenv("SERIAL_PORT", "COM5")
SERIAL_BAUD = int(os.getenv("SERIAL_BAUD", "115200"))
CAMERA_INDEX = int(os.getenv("CAMERA_INDEX", "0"))
YOLO_MODEL = os.getenv("YOLO_MODEL", "models/best.pt")
DEFAULT_SPEED = int(os.getenv("DEFAULT_SPEED", "150"))

serial_conn = None
serial_lock = threading.Lock()
serial_state = {"connected": False, "port": SERIAL_PORT, "state": "disconnected", "speed": 0, "last_message": ""}
camera = None
camera_lock = threading.Lock()
latest_frame = None
camera_state = {"connected": False, "index": CAMERA_INDEX, "error": ""}
yolo_model = None
yolo_state = {"available": False, "model": YOLO_MODEL, "message": "YOLO not configured"}
events = deque(maxlen=100)
last_detection_time = 0

def add_event(kind, message, confidence=None):
    events.appendleft({
        "time": time.strftime("%H:%M:%S"),
        "kind": kind,
        "message": message,
        "confidence": round(float(confidence), 3) if confidence is not None else None
    })

def connect_serial():
    global serial_conn
    if serial_conn and serial_conn.is_open:
        return
    try:
        serial_conn = serial.Serial(SERIAL_PORT, SERIAL_BAUD, timeout=0.15, write_timeout=0.5)
        time.sleep(2.0)  # ESP32 may reboot when serial opens
        serial_state.update(connected=True, port=SERIAL_PORT, state="idle", speed=0, last_message="Serial connected")
        threading.Thread(target=serial_reader, daemon=True).start()
    except Exception as exc:
        serial_conn = None
        serial_state.update(connected=False, port=SERIAL_PORT, state="disconnected", last_message=str(exc))

def serial_reader():
    while serial_conn and serial_conn.is_open:
        try:
            line = serial_conn.readline().decode("utf-8", errors="ignore").strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                if data.get("type") == "status":
                    serial_state.update(
                        connected=True,
                        state=data.get("state", serial_state["state"]),
                        speed=data.get("speed", serial_state["speed"]),
                        last_message=line
                    )
                elif data.get("type") == "event":
                    add_event(data.get("kind", "hardware"), data.get("message", line))
            except json.JSONDecodeError:
                serial_state["last_message"] = line
        except Exception as exc:
            serial_state.update(connected=False, state="disconnected", last_message=str(exc))
            break

def send_command(command, speed=None):
    global serial_conn
    if command not in {"forward", "backward", "left", "right", "stop"}:
        return False, "Unsupported command"
    if not serial_conn or not serial_conn.is_open:
        connect_serial()
    if not serial_conn or not serial_conn.is_open:
        return False, "ESP32 serial connection unavailable. Check SERIAL_PORT and USB cable."
    payload = {"cmd": command, "speed": max(0, min(255, int(speed if speed is not None else DEFAULT_SPEED)))}
    try:
        with serial_lock:
            serial_conn.write((json.dumps(payload) + "\n").encode("utf-8"))
        return True, "Command sent"
    except Exception as exc:
        return False, str(exc)

def load_yolo():
    global yolo_model
    model_path = ROOT / YOLO_MODEL
    if not model_path.exists():
        yolo_state.update(available=False, message=f"Model file not found: {YOLO_MODEL}")
        return
    try:
        from ultralytics import YOLO
        yolo_model = YOLO(str(model_path))
        yolo_state.update(available=True, message="YOLO model loaded")
    except Exception as exc:
        yolo_state.update(available=False, message=f"YOLO load failed: {exc}")

def camera_worker():
    global camera, latest_frame, last_detection_time
    camera = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_DSHOW if os.name == "nt" else cv2.CAP_ANY)
    if not camera.isOpened():
        camera_state.update(connected=False, error="Cannot open camera. Try CAMERA_INDEX=1 or close other camera apps.")
        return
    camera_state.update(connected=True, error="")
    while True:
        ok, frame = camera.read()
        if not ok:
            camera_state.update(connected=False, error="Camera frame read failed")
            time.sleep(0.3)
            continue
        display = frame.copy()
        if yolo_model is not None:
            try:
                result = yolo_model.predict(frame, conf=0.35, verbose=False)[0]
                display = result.plot()
                now = time.time()
                for box in result.boxes:
                    conf = float(box.conf[0])
                    cls_id = int(box.cls[0])
                    label = yolo_model.names.get(cls_id, str(cls_id))
                    if now - last_detection_time > 2:
                        add_event("YOLO", f"Detected: {label}", conf)
                        last_detection_time = now
            except Exception as exc:
                yolo_state["message"] = f"Inference error: {exc}"
        with camera_lock:
            latest_frame = display
        time.sleep(0.01)

@app.route("/")
def index():
    return send_from_directory("dashboard", "index.html")

@app.get("/api/status")
def status():
    if not serial_conn or not serial_conn.is_open:
        # Retry quietly so plugging in the board after startup can work.
        connect_serial()
    return jsonify({
        "esp32": serial_state,
        "camera": camera_state,
        "yolo": yolo_state,
        "available_ports": [p.device for p in list_ports.comports()]
    })

@app.post("/api/move")
def move():
    data = request.get_json(silent=True) or {}
    ok, message = send_command(data.get("command", ""), data.get("speed", DEFAULT_SPEED))
    return jsonify({"ok": ok, "message": message}), (200 if ok else 503)

@app.post("/api/stop")
def stop():
    ok, message = send_command("stop", 0)
    return jsonify({"ok": ok, "message": message}), (200 if ok else 503)

@app.get("/api/events")
def get_events():
    return jsonify(list(events))

@app.get("/video_feed")
def video_feed():
    def generate():
        while True:
            with camera_lock:
                frame = None if latest_frame is None else latest_frame.copy()
            if frame is None:
                time.sleep(0.1)
                continue
            ok, buffer = cv2.imencode(".jpg", frame)
            if ok:
                yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + buffer.tobytes() + b"\r\n")
            time.sleep(0.04)
    return Response(generate(), mimetype="multipart/x-mixed-replace; boundary=frame")

if __name__ == "__main__":
    load_yolo()
    threading.Thread(target=camera_worker, daemon=True).start()
    connect_serial()
    host = os.getenv("WEB_HOST", "127.0.0.1")
    port = int(os.getenv("WEB_PORT", "5000"))
    print(f"RailGuard dashboard: http://{host}:{port}")
    app.run(host=host, port=port, threaded=True, debug=False)
