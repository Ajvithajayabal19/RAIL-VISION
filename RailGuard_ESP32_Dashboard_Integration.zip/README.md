# RailGuard – ESP32 + Laptop USB Camera + Dashboard

This is a starter integration package for the AI Railway Track Monitoring robot.

## What is included
- ESP32 Arduino firmware for two DC motors through an L298N driver.
- Python Flask backend with USB-serial communication to the ESP32.
- Laptop USB-camera preview using OpenCV.
- Optional YOLO inference using Ultralytics when a compatible model file is supplied.
- Browser dashboard with movement controls, emergency stop, camera preview, connection status and detection events.

> Important: The uploaded photo does not clearly show the exact ESP32 pin wiring or any track-detection sensor modules. The pin mapping below is a configurable starting point, not a verified match to your physical wiring. Check every wire before powering the motors.

## Hardware assumed
- ESP32 development board
- L298N dual H-bridge motor driver
- Two DC geared motors
- Battery pack for motors
- Laptop USB camera
- Laptop running the Python backend

## Safety first
1. Lift the robot wheels off the ground for the first motor test.
2. Disconnect the battery while changing wiring.
3. Connect the motor battery only to the L298N motor supply input (`+12V/Vs` and `GND`).
4. Connect L298N GND and ESP32 GND together (common ground).
5. Power the ESP32 from the laptop USB during initial testing. Do not connect the motor battery directly to the ESP32.
6. If the L298N has an onboard 5V regulator/jumper, check the exact board documentation before using its 5V pin.
7. Use a suitable regulated supply/buck converter if you later want to power the ESP32 from the robot battery.
8. Confirm the battery pack voltage and motor voltage ratings before connecting it.

## Suggested L298N-to-ESP32 mapping
Remove the ENA/ENB jumpers if you want ESP32 PWM speed control.

| L298N | ESP32 GPIO | Purpose |
|---|---:|---|
| ENA | GPIO 25 | Left motor speed (PWM) |
| IN1 | GPIO 26 | Left motor direction |
| IN2 | GPIO 27 | Left motor direction |
| ENB | GPIO 14 | Right motor speed (PWM) |
| IN3 | GPIO 32 | Right motor direction |
| IN4 | GPIO 33 | Right motor direction |
| GND | GND | Common ground |

L298N motor outputs:
- OUT1/OUT2 -> left motor
- OUT3/OUT4 -> right motor

Do not rely on wire colours. Verify the labels printed on your L298N board.

## Install and run (Windows PowerShell)
1. Install Python 3.10 or newer and Arduino IDE.
2. Copy this folder to your computer.
3. Open PowerShell in this folder and run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```

4. Edit `.env` and set the ESP32 serial port, for example `COM5`. Find it in Arduino IDE -> Tools -> Port.
5. Upload `firmware/railguard_esp32.ino` to the ESP32 using Arduino IDE. Select the correct ESP32 board and port.
6. Close Arduino Serial Monitor before starting the Python backend (only one program can use the serial port at a time).
7. Start the backend:

```powershell
python app.py
```

8. Open `http://127.0.0.1:5000` in your browser.

## Camera
The backend tries camera index `0` by default. If the preview is black, change `CAMERA_INDEX` in `.env` to `1` or `2`, close other camera applications, and restart the backend.

## Optional YOLO setup
This project does not include model weights. Place your trained YOLO weights in `models/best.pt` and set:

```env
YOLO_MODEL=models/best.pt
```

Install the optional package:

```powershell
pip install ultralytics
```

Restart the backend. If the model cannot be loaded, the camera preview still works with OpenCV and the dashboard reports that YOLO is unavailable. Your model must be trained for the classes you need, such as rail crack, obstacle, missing fastener, or other project-specific defects. A generic pretrained model will not reliably detect railway defects.

## API endpoints
- `GET /api/status` – ESP32, camera and YOLO status
- `POST /api/move` – JSON `{"command":"forward","speed":150}`
- `POST /api/stop` – emergency stop
- `GET /api/events` – recent detections/events
- `GET /video_feed` – live MJPEG camera stream

Movement commands: `forward`, `backward`, `left`, `right`, `stop`.

## Serial protocol
Backend sends newline-terminated JSON:
`{"cmd":"forward","speed":150}`

ESP32 responds with JSON status lines, for example:
`{"type":"status","state":"forward","speed":150,"uptime_ms":12345}`

## Before your final demo
- Confirm the GPIO mapping matches your actual wiring.
- Confirm both motors rotate in the intended direction; if one is reversed, swap that motor's two output wires or invert it in firmware.
- Add and test your own trained YOLO weights.
- Test obstacle/crack detections on recorded sample images before using live robot movement.
- This prototype is not a certified railway safety device and must not be used on active railway tracks.
