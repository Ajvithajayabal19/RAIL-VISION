#include <Arduino.h>
#include <ArduinoJson.h>
#include <esp_arduino_version.h>

// Suggested L298N pin map. Change these to match your actual wiring.
const int ENA = 25; // Left motor PWM
const int IN1 = 26;
const int IN2 = 27;
const int ENB = 14; // Right motor PWM
const int IN3 = 32;
const int IN4 = 33;

const int PWM_FREQ = 1000;
const int PWM_RESOLUTION = 8; // 0-255
const int PWM_CH_A = 0;
const int PWM_CH_B = 1;

String currentState = "idle";
int currentSpeed = 0;
unsigned long lastStatus = 0;

void setMotors(int leftA, int leftB, int rightA, int rightB, int speedValue) {
  digitalWrite(IN1, leftA); digitalWrite(IN2, leftB);
  digitalWrite(IN3, rightA); digitalWrite(IN4, rightB);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(ENA, speedValue);
  ledcWrite(ENB, speedValue);
#else
  ledcWrite(PWM_CH_A, speedValue);
  ledcWrite(PWM_CH_B, speedValue);
#endif
}

void stopMotors() {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(ENA, 0);
  ledcWrite(ENB, 0);
#else
  ledcWrite(PWM_CH_A, 0);
  ledcWrite(PWM_CH_B, 0);
#endif
  digitalWrite(IN1, LOW); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW); digitalWrite(IN4, LOW);
  currentState = "stop";
  currentSpeed = 0;
}

void reportStatus() {
  StaticJsonDocument<160> doc;
  doc["type"] = "status";
  doc["state"] = currentState;
  doc["speed"] = currentSpeed;
  doc["uptime_ms"] = millis();
  serializeJson(doc, Serial);
  Serial.println();
}

void executeCommand(String cmd, int speedValue) {
  speedValue = constrain(speedValue, 0, 255);
  currentSpeed = speedValue;

  if (cmd == "forward") {
    setMotors(HIGH, LOW, HIGH, LOW, speedValue);
    currentState = "forward";
  } else if (cmd == "backward") {
    setMotors(LOW, HIGH, LOW, HIGH, speedValue);
    currentState = "backward";
  } else if (cmd == "left") {
    setMotors(LOW, HIGH, HIGH, LOW, speedValue);
    currentState = "left";
  } else if (cmd == "right") {
    setMotors(HIGH, LOW, LOW, HIGH, speedValue);
    currentState = "right";
  } else {
    stopMotors();
  }
  reportStatus();
}

void setup() {
  Serial.begin(115200);
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(ENA, PWM_FREQ, PWM_RESOLUTION);
  ledcAttach(ENB, PWM_FREQ, PWM_RESOLUTION);
#else
  ledcSetup(PWM_CH_A, PWM_FREQ, PWM_RESOLUTION);
  ledcSetup(PWM_CH_B, PWM_FREQ, PWM_RESOLUTION);
  ledcAttachPin(ENA, PWM_CH_A);
  ledcAttachPin(ENB, PWM_CH_B);
#endif
  stopMotors();
  reportStatus();
}

void loop() {
  if (Serial.available()) {
    String line = Serial.readStringUntil('\n');
    StaticJsonDocument<192> doc;
    DeserializationError err = deserializeJson(doc, line);
    if (!err) {
      String cmd = doc["cmd"] | "stop";
      int speedValue = doc["speed"] | 150;
      executeCommand(cmd, speedValue);
    } else {
      stopMotors();
      reportStatus();
    }
  }
  if (millis() - lastStatus > 2000) {
    lastStatus = millis();
    reportStatus();
  }
}
