# Wiring checklist – verify before powering

## L298N
- Motor A terminals OUT1/OUT2 -> left DC motor.
- Motor B terminals OUT3/OUT4 -> right DC motor.
- Battery positive -> L298N `12V` / `Vs` input (only if compatible with motor rating).
- Battery negative -> L298N `GND`.
- ESP32 `GND` -> L298N `GND` (common ground).
- ENA -> GPIO25; IN1 -> GPIO26; IN2 -> GPIO27.
- ENB -> GPIO14; IN3 -> GPIO32; IN4 -> GPIO33.
- Remove ENA and ENB jumpers for PWM control, if present.

## ESP32 power
- Initially power ESP32 from laptop USB.
- Do not connect battery positive to ESP32 3V3 or VIN.
- Do not assume the L298N 5V terminal is a safe ESP32 supply. Verify board regulator/jumper and use a regulated buck converter if required.

## Sensors and LEDs
The supplied photo does not clearly identify the sensor models or their signal wiring. This package therefore does not assign sensor GPIOs or claim sensor readings. Add each sensor only after confirming its exact model, operating voltage, output type and pin labels. ESP32 GPIOs are 3.3V logic; never feed 5V directly into an ESP32 GPIO.

## First test
1. Put robot on a stand so wheels cannot touch the floor.
2. Connect USB and upload firmware.
3. Start Python backend and open dashboard.
4. Press STOP first; then test forward at low speed.
5. If a motor runs backward, power down and swap that motor's two output wires.
6. Test left/right/backward and emergency stop.
